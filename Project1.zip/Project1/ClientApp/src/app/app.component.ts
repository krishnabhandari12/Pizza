import { Component, DoCheck, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PizzaService } from './pizza.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit, DoCheck{
  title = 'app';
  public itemInCarts: number = 0;
  public currentCart = [];
  constructor(private pservice: PizzaService) {
    this.pservice.setValue(this.currentCart)
  }

  ngOnInit() {
    this.pservice.getValue().subscribe(val => this.itemInCarts = val.length);
  }

  ngDoCheck() {
    this.pservice.getValue().subscribe(val => this.itemInCarts = val.length);
  }
}
