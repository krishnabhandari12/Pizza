import { Component, Input, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
import {  Ingredients, Order } from '../model/model';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-build-pizza',
  templateUrl: './buildpizza.component.html',
})
export class BuildPizzaComponent implements OnInit {

  public selectedCrust: string = '';
  public selectedSauce: string = '';
  public selectedToppings: string = '';
  public totalPrice: number = 0;
  public cPrice: number | undefined = 0;
  public sPrice: number | undefined = 0;
  public tPrice: number = 0;
  public bPrice: number = 0
  public crusts: Ingredients[] = [];
  public suaces: Ingredients[] = [];
  public toppings = new FormControl('');
  public toppingList: Ingredients[] = [];
  public cartSummary: any;
  public pizzaObject: any;
  public currentCart: any;
  public quantity:number = 0
  constructor(private pservice: PizzaService,
    private Activatedroute: ActivatedRoute,
    private _snackBar: MatSnackBar) { }

  ngOnInit() {

    this.pservice.getCrust().subscribe(val => {
      this.crusts = val;
    });

    this.pservice.getToppings().subscribe(val => {
      this.toppingList = val;
    });

    this.pservice.getSauce().subscribe(val => {
      this.suaces = val;
    });

    this.toppings.valueChanges.subscribe(val => {
      this.setValue(val);
    });

    this.Activatedroute.paramMap
      .subscribe(params => {
        let id = params.get("id");
        this.pizzaObject = this.pservice._pizzas.find(x => x.key == id);
      });

    this.pservice.getValue().subscribe(val => this.currentCart = val);
  }

  onSelectCrust() {
    this.cPrice = 0;
    this.cPrice = this.crusts?.find(c => c.key == this.selectedCrust)?.price;
    if (this.cPrice) {
      this.calculatePrice();
    }
  }

  onSelectSauce() {
    this.sPrice = 0;
    this.sPrice = this.suaces?.find(c => c.key == this.selectedSauce)?.price;
    if (this.sPrice) {
      this.calculatePrice();
    }
  }

  setValue(value: any) {
    this.tPrice = 0;
    if (value) {
      this.selectedToppings = value.toString();
      value.forEach((topping: any) => {
        let price = this.toppingList?.find(x => x.key == topping)?.price;
        if (price) {
          this.tPrice = this.tPrice + price;
        }
      });
      this.calculatePrice();
    }
  }

  calculatePrice() {
    this.totalPrice = this.pizzaObject.price + this.cPrice + this.tPrice + this.sPrice;
  }

  public addToCart() {
    this.quantity = this.quantity + 1;
    this.calculatePrice();
    if (this.currentCart?.length == 0) {
      let cartSummary = {
        name: this.pizzaObject.key,
        quantity: 1,
        price: this.totalPrice,
        crust: this.selectedCrust.toString(),
        sauce: this.selectedSauce.toString(),
        toppings: this.selectedToppings,
        img: this.pizzaObject.img
      }
      this.currentCart.push(cartSummary);
    }
    else if (this.currentCart?.length > 0) {
      let itemFound = this.currentCart.some((x: Order) => x.name == this.pizzaObject.key);
      if (!itemFound) {
        let cartSummary = {
          name: this.pizzaObject.key,
          quantity: 1,
          price: this.totalPrice,
          crust: this.selectedCrust.toString(),
          sauce: this.selectedSauce.toString(),
          toppings: this.selectedToppings,
          img: this.pizzaObject.img
        }
        this.currentCart.push(cartSummary);
      }
      else {
        this.currentCart.map((x: Order) => {
          x.quantity = x.quantity + 1;
          x.price = x.quantity * this.totalPrice;
        })
      }
    }
    this.pservice.setValue(this.currentCart);
    this._snackBar.open('Item added to cart successfully.');
  }

  removeFromCart() {
    this.quantity = this.quantity - 1;
    let occurunce = this.currentCart.length;
    if (occurunce > 1) {
      this.currentCart.map((x: Order) => {
        x.quantity = x.quantity - 1;
        x.price = x.quantity * this.totalPrice;
      })
    }
    else {
      this.currentCart = [];
    }
    this._snackBar.open('Item removed from cart successfully.');
  }
}

