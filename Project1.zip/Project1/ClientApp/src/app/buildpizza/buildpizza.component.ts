import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Iingredients } from '../model/model';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-build-pizza',
  templateUrl: './buildpizza.component.html',
})
export class BuildPizzaComponent implements OnInit {

  public selectedCrust: string = '';
  public selectedSauce: string = '';
  public selectedToppings: string = '';
  public totalPrice: number = 0;
  public cPrice: number | undefined = 0;
  public sPrice: number | undefined = 0;
  public tPrice: number = 0;
  public bPrice: number = 0
  public crusts: Iingredients[] = [];
  public suaces: Iingredients[] = [];
  public toppings = new FormControl('');
  public toppingList: Iingredients[] = [];
  public msg: string = "";
  public cartSummary: any;
  public pizzaname: string = "";

  constructor(private pservice: PizzaService,
    private Activatedroute: ActivatedRoute) { }

  ngOnInit() {

    this.pservice.getCrust().subscribe(val => {
      this.crusts = val;
    });

    this.pservice.getToppings().subscribe(val => {
      this.toppingList = val;
    });

    this.pservice.getSauce().subscribe(val => {
      this.suaces = val;
    });

    this.toppings.valueChanges.subscribe(val => {
      this.setValue(val);
    });

    this.Activatedroute.queryParams
      .subscribe(params => {
        this.bPrice = +params['price'];
        this.pizzaname = params['pizza'];
      });
  }

  onSelectCrust() {
    this.cPrice = 0;
    this.cPrice = this.crusts?.find(c => c.key == this.selectedCrust)?.price;
    if (this.cPrice) {
      this.calculatePrice(this.cPrice, this.tPrice, this.sPrice);
    }
    this.msg = '';
  }

  onSelectSauce() {
    this.sPrice = 0;
    this.sPrice = this.suaces?.find(c => c.key == this.selectedSauce)?.price;
    if (this.sPrice) {
      this.calculatePrice(this.cPrice, this.tPrice, this.sPrice);
    }
  }

  setValue(value: any) {
    this.tPrice = 0;
    if (value) {
      this.selectedToppings = value.toString();
      value.forEach((topping: any) => {
        let price = this.toppingList?.find(x => x.key == topping)?.price;
        if (price) {
          this.tPrice = this.tPrice + price;
        }
      });
      this.calculatePrice(this.cPrice, this.tPrice, this.sPrice);
    }
  }

  calculatePrice(cprice: any, tprice: any, sPrice: any) {
    this.totalPrice = cprice + tprice + sPrice + this.bPrice;
    this.cartSummary = {
      itemInCarts: this.pizzaname,
      priceOfCart: this.totalPrice
    }
  }

  placeOrder() {
    let pizzaDetails = {
      price: this.totalPrice,
      crust: this.selectedCrust.toString(),
      sauce: this.selectedSauce.toString(),
      toppings: this.selectedToppings
    }
    if (pizzaDetails.crust) {
      this.pservice.placeOrder(pizzaDetails).subscribe((val: number) => {
        this.msg = `Congratulations! Order ${val} placed successfully.`;
      });
    }
    else {
      this.msg = "Please choose crust to proceed.";
    }   
    this.clearAll();
  }

  clearAll() {
    this.totalPrice = 0;
    this.cPrice = 0;
    this.sPrice = 0;
    this.tPrice = 0;
    this.selectedCrust = "";
    this.selectedSauce = "";
    this.selectedToppings = "";
    this.toppings.setValue(null);
    this.cartSummary = [];
  }
}

