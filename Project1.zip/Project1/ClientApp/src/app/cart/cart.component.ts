import { Component, Inject, Input, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PizzaService } from '../pizza.service';
import { Order } from '../model/model';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html'
})
export class CartComponent implements OnInit {

  public msg: string = '';
  public currentCart: Order[] = [];
  public grandTotal: number = 0;
  constructor(private pservice: PizzaService,
    private _snackBar: MatSnackBar,
    private _router: Router ) {  
  }

  ngOnInit() {
    this.pservice.getValue().subscribe(val => {
      this.currentCart = val;
      this.currentCart.forEach(x => {
        this.grandTotal = this.grandTotal + x.price;
      })
    });
   
  }

  placeOrder() {
    if (this.currentCart.length > 0) {
      this.pservice.placeOrder(this.currentCart).subscribe((val: number) => {
        this._snackBar.open(`Congratulations! Order ${val} placed successfully.`);
        this.currentCart = [];
        this.pservice.setValue(this.currentCart);
        this._router.navigateByUrl('/home');
      });

    }
  }

  removeFromCart() {
    let index = this.currentCart.findIndex(x => x.name);
    this.currentCart.splice(index, 1);
  }

  clearCart() {
    this.currentCart = [];
  }
}
