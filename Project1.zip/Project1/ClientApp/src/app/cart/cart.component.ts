import { Component, Inject, Input, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html'
})
export class CartComponent {

  @Input() cartSummary: any;
  public msg: string = '';
  constructor(private pservice: PizzaService) {
  }

  placeOrder() {
    let pizzaDetails = {
      price: this.cartSummary?.priceOfCart,
      toppings: this.cartSummary?.itemInCarts,
      crust: this.cartSummary?.crust ? this.cartSummary.crust : '',
      sauce: this.cartSummary?.sauce ? this.cartSummary.sauce : ''
    }
    if (pizzaDetails) {
      this.pservice.placeOrder(pizzaDetails).subscribe((val: number) => {
        this.msg = `Congratulations! Order ${val} placed successfully.`;
      });
    }
  }
}
