import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Ingredients, Order } from '../model/model';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public pizzas: Ingredients[] = [];
  public selectedPizza: string = '';

  constructor(private pservice: PizzaService, private _snackBar: MatSnackBar) {
  }

  ngOnInit() {
    this.pservice.getPizza().subscribe(val => {
      this.pizzas = val;
    });
  }

  onSelectPizza() {  
  }

}

