import { Component, OnInit } from '@angular/core';
import { Iingredients } from '../model/model';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent implements OnInit {

  public pizzas: Iingredients[] = [];
  public msg: string = '';
  public selectedPizza: string = '';
  public selectedPizzaObject: Iingredients | undefined;
  public totalPrice: number = 0;
  public itemInCarts: string = '';
  public priceOfCart: number = 0;
  public cartSummary: any;

  constructor(private pservice: PizzaService) {
  }

  ngOnInit() {
    this.pservice.getPizza().subscribe(val => {
      this.pizzas = val;
    });
  }

  onSelectPizza() {
    this.msg = "";
    this.selectedPizzaObject = this.pizzas.find(x => x.key == this.selectedPizza);   
  }

  addToCart() {
    this.itemInCarts = this.selectedPizza;
    if (this.selectedPizzaObject?.price) {
      this.priceOfCart = this.selectedPizzaObject.price;
      this.msg = 'Item added to cart successfully.';
    }
    //this.msg = 'Item added to cart successfully.';
    //if (!this.itemInCarts.includes(this.selectedPizza)) {
    //  this.itemInCarts = this.itemInCarts.concat(this.selectedPizza);
    //  if (this.selectedPizzaObject?.price) {
    //    this.priceOfCart = this.priceOfCart + this.selectedPizzaObject.price;
    //  }
    //  this.msg = 'Item added to cart successfully.';
    //}
    this.cartSummary = {
      itemInCarts: this.itemInCarts,
      priceOfCart: this.priceOfCart
    }
  }

  clearCart() {
    this.itemInCarts = '';
    this.priceOfCart = 0;
    this.cartSummary = [];
    this.selectedPizza = '';
    this.selectedPizzaObject = undefined;
    this.msg = "Cart cleared successfully."
  }

}

