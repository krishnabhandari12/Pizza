import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Iingredients, Order } from '../model/model';
import { PizzaService } from '../pizza.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public pizzas: Iingredients[] = [];
  public msg: string = '';
  public selectedPizza: string = '';
  public selectedPizzaObject: Iingredients | undefined;
  public totalPrice: number = 0;
  public itemInCarts: string = '';
  public quantity: number = 0
  public priceOfCart: number = 0;
  public isPizzaAlreadyAdded: boolean = false;
  public currentCart: any;

  constructor(private pservice: PizzaService, private _snackBar: MatSnackBar) {
  }

  ngOnInit() {
    this.pservice.getPizza().subscribe(val => {
      this.pizzas = val;
    });
  }

  onSelectPizza() {
    this.msg = "";
    this.selectedPizzaObject = this.pizzas.find(x => x.key == this.selectedPizza);
    this.isPizzaAlreadyAdded = this.currentCart?.some((x: Order) => x.name == this.selectedPizzaObject?.key);
  }

}

