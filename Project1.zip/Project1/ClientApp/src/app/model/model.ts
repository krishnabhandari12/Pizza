

export class Order {
  public name: string = "";
  public quantity: number = 0;
  public price: number = 0;
  public crust: string = "";
  public sauce: string = "";
  public toppings: string = "";
  public img: string = "";
  public mobileNumber: number = 0;
  public address: string = ""
}

export class Ingredients {
  public key: string = "";
  public item: string = "";
  public price: number = 0;
  public img: string = "";
}
