export interface Iingredients {
  key: string;
  item: string;
  price: number;
  img: string;
}

export class Order {
  public name: string = "";
  public quantity: number = 0;
  public price: number = 0;
  public crust: string = "";
  public sauce: string = "";
  public toppings: string = "";
  public img: string = "";
}

export class Ingredients {
  public key: string = "";
  public item: string = "";
  public price: number = 0;
  public img: string = "";
}
