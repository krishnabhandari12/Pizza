import { HttpClient, HttpErrorResponse, HttpEvent } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { BehaviorSubject, map, Observable } from 'rxjs';
import { Iingredients, Ingredients, Order } from './model/model';

@Injectable({
  providedIn: 'root',
})
export class PizzaService {
  public _baseUrl: string = '';
  public _http: HttpClient;
  public _pizzas: Ingredients[] = [];
  private myOrder = new BehaviorSubject<Order[]>([]);

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this._baseUrl = baseUrl;
    this._http = http;
  }

  public setValue(value: Order[]) {
    this.myOrder.next(value);
  }

  public getValue() {
    return this.myOrder.asObservable();
  }

  public getToppings(): Observable<Iingredients[]> {
    return this._http.get<Iingredients[]>(this._baseUrl + 'pizza/gettoppings')
      .pipe(map(val => {
        return val;
      }));
  }

  public getSauce(): Observable<Iingredients[]> {
    return this._http.get<Iingredients[]>(this._baseUrl + 'pizza/getsauce')
      .pipe(map(val => {
        return val;
      }));
  }

  public getCrust(): Observable<Iingredients[]> {
    return this._http.get<Iingredients[]>(this._baseUrl + 'pizza/getcrust')
      .pipe(map(val => {
        return val;
      }));
  }

  public getPizza(): Observable<Ingredients[]> {
    return this._http.get<Iingredients[]>(this._baseUrl + 'pizza/getpizza')
      .pipe(map(val => {
        this._pizzas = val;
        return this._pizzas;
      }));
  }

  public placeOrder(pizzaDetails: Order[]): any {
    return this._http.post<Order[]>(this._baseUrl + 'pizza/placeorder', pizzaDetails)
      .pipe(map(val => {
        return val;
      }));
  }
}
