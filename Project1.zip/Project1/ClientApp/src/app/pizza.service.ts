import { HttpClient } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Iingredients } from './model/model';

@Injectable({
  providedIn: 'root',
})
export class PizzaService {
  public _baseUrl: string = '';
  public _http: HttpClient;
  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this._baseUrl = baseUrl;
    this._http = http;
  }

  public getToppings(): Observable<Iingredients[]> {
    return this._http.get<Iingredients[]>(this._baseUrl + 'pizza/gettoppings')
      .pipe(map(val => {
        return val;
      }));
  }

  public getSauce(): Observable<Iingredients[]> {
    return this._http.get<Iingredients[]>(this._baseUrl + 'pizza/getsauce')
      .pipe(map(val => {
        return val;
      }));
  }

  public getCrust(): Observable<Iingredients[]> {
    return this._http.get<Iingredients[]>(this._baseUrl + 'pizza/getcrust')
      .pipe(map(val => {
        return val;
      }));
  }

  public getPizza(): Observable<Iingredients[]> {
    return this._http.get<Iingredients[]>(this._baseUrl + 'pizza/getpizza')
      .pipe(map(val => {
        return val;
      }));
  }

  public placeOrder(pizzaDetails:any): Observable<number> {
    return this._http.post<number>(this._baseUrl + 'pizza/placeorder', pizzaDetails )
      .pipe(map(val => {
        return val;
      }));
  }
}
