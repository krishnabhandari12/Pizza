import { Injectable } from "@angular/core";
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from "rxjs";
import { catchError, map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { MatSnackBar } from "@angular/material/snack-bar";

@Injectable()
export class GlobalHttpInterceptorService implements HttpInterceptor {

  constructor(private _snackBar: MatSnackBar) {
  }


  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      catchError((error) => {
        if (error instanceof HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            this._snackBar.open('Oops. Something happened. Please try again.');
          } else {
            this._snackBar.open(`Oops. Something happened. Please try again.`);           
          }
        }
        else {
          this._snackBar.open('Opps. Something happened. Please try again.');
        }
        return throwError(error);


      })
    )
  }
}
