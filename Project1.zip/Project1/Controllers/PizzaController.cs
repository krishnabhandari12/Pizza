﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Project1.Helper;
using Project1.Interfaces;

namespace Project1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PizzaController : ControllerBase
    {
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly IPizzaService _service;
        public PizzaController(IWebHostEnvironment webHostEnvironment,
            IPizzaService service)
        {
            _webHostEnvironment = webHostEnvironment;
            _service = service;
        }

        [HttpGet("GetToppings")]
        public ActionResult<List<Ingridients>> GetToppings()
        {
            var obj = _service.getTopping();
            return obj?.Count > 0 ? obj : NotFound();
        }

        [HttpGet("GetSauce")]
        public ActionResult<List<Ingridients>> GetSauce()
        {
            var obj = _service.getSauce();
            return obj?.Count > 0 ? obj : NotFound();

        }

        [HttpGet("GetCrust")]
        public ActionResult<List<Ingridients>> GetCrust()
        {
            var obj = _service.getCrust();
            return obj?.Count > 0 ? obj : NotFound();
        }

        [HttpGet("GetPizza")]
        public ActionResult<List<Ingridients>> GetPizza()
        {
            var obj = _service.getPizza();
            return obj?.Count > 0 ? obj : NotFound();
        }

        [HttpPost("PlaceOrder")]
        public ActionResult<int> PlaceOrder([FromBody] PizzaOrderDetails[] orderDetails)
        {
            var obj = _service.placeOrder(orderDetails);
            return obj > 0 ? obj : NotFound();         
        }

    }
}