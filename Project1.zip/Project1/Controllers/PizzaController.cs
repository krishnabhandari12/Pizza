﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Project1.Helper;

namespace Project1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PizzaController : ControllerBase
    {
        private readonly IWebHostEnvironment _webHostEnvironment;
        public PizzaController( IWebHostEnvironment webHostEnvironment)
        {           
            _webHostEnvironment = webHostEnvironment;
        }

        [HttpGet("GetToppings")]
        public List<Ingridients> GetToppings()
        { 
            var list = new List<Ingridients>
            {
                new Ingridients { Key = "cheese", Item = "Extra cheese", Price = 100 },
                new Ingridients { Key = "onion", Item = "Onion", Price = 50 },
                new Ingridients { Key = "mushroom", Item = "Mushroom", Price = 70 },
                new Ingridients { Key = "tomato", Item = "Tomato", Price = 50 },
                new Ingridients { Key = "pepperoni", Item = "Pepperoni", Price = 100 }
            };
            return list;
        }

        [HttpGet("GetSauce")]
        public List<Ingridients> GetSauce()
        {
            var list = new List<Ingridients>
            {
                new Ingridients { Key = "mariana", Item = "Mariana", Price = 100 },
                new Ingridients { Key = "ranch", Item = "Ranch", Price = 50 },
                new Ingridients { Key = "cheese", Item = "Cheese", Price = 70 }
            };
            return list;
        }

        [HttpGet("GetCrust")]
        public List<Ingridients> GetCrust()
        {
            var list = new List<Ingridients>
            {
                new Ingridients { Key = "small", Item = "Small", Price = 100 },
                new Ingridients { Key = "medium", Item = "Medium", Price = 200 },
                new Ingridients { Key = "large", Item = "Large", Price = 300 }
            };
            return list;
        }

        [HttpGet("GetPizza")]
        public List<Ingridients> GetPizza()
        {
            var list = new List<Ingridients>
            {
                new Ingridients { Key = "Margarita", Item = "Tomato, Cheese", Price = 250,
                    Img="https://static8.depositphotos.com/1177973/861/i/600/depositphotos_8618524-stock-photo-delicious-pizza-with-seafood-on.jpg" },
                new Ingridients { Key = "Farmhouse", Item = "Baby Corn, Tomato, Cheese", Price = 400,
                    Img="https://img.freepik.com/free-photo/close-up-italian-pizza-about-cheese-it-stick-selective-focus-generative-ai_1258-153063.jpg"},
                new Ingridients { Key = "Veg Extra", Item = "Capsicum, Corn, Cheese", Price = 350, 
                    Img="https://st2.depositphotos.com/1692343/5636/i/600/depositphotos_56360353-stock-photo-hot-homemade-pepperoni-pizza.jpg" },
                new Ingridients { Key = "Italiano Delight", Item = "Mushroom, Olive, Cheese", Price = 450,
                    Img="https://st.depositphotos.com/1003814/5052/i/600/depositphotos_50523105-stock-photo-pizza-with-tomatoes.jpg" },
                new Ingridients { Key = "Mexican Veg", Item = "Red Papparika, Jalapeno, Cheese", Price = 490,
                    Img="https://st.depositphotos.com/1177973/1687/i/600/depositphotos_16872433-stock-photo-tasty-pizza-with-vegetables-chicken.jpg" },
                new Ingridients { Key = "Peppy Paneer", Item = "Paneer, Onion, Cheese", Price = 390,
                    Img="https://st.depositphotos.com/1144352/3656/i/600/depositphotos_36567413-stock-photo-pizza.jpg" }
            };
            return list;
        }

        [HttpPost("PlaceOrder")]
        public int PlaceOrder([FromBody] PizzaOrderDetails orderDetails)
        {
            var details = JsonConvert.SerializeObject(orderDetails);
            var order = new Random().Next();
            System.IO.File.WriteAllText(@"C:\Pizza\" + $"{order}" + ".txt", details);
            return order;
        }

    }
}