namespace Project1.Helper
{
    public class Ingridients
    {
        public string Key { get; set; }
        public string Item { get; set; }
        public int Price { get; set; }

        public string Img { get; set; }
    }

    public class PizzaOrderDetails
    {
        public int Price { get; set; }
        public string Crust { get; set; }
        public string Sauce { get; set; }
        public string Toppings { get; set; }
    }

}