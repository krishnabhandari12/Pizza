﻿using Project1.Helper;

namespace Project1.Interfaces
{
    public interface IPizzaService
    {
        List<Ingridients> getPizza();
        List<Ingridients> getSauce();
        List<Ingridients> getCrust();
        List<Ingridients> getTopping();
        int placeOrder(PizzaOrderDetails[] orderDetails);

    }
}
