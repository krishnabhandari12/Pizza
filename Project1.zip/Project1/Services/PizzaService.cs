﻿using Newtonsoft.Json;
using Project1.Helper;
using Project1.Interfaces;

namespace Project1.Services
{
    public class PizzaService : IPizzaService
    {
        public PizzaService()
        {

        }

        public List<Ingridients> getPizza()
        {
            string text = File.ReadAllText(@"./wwwroot/pizza.json");
            return JsonConvert.DeserializeObject<List<Ingridients>>(text);
        }

        public List<Ingridients> getTopping()
        {

            string text = System.IO.File.ReadAllText(@"./wwwroot/toppings.json");
            return JsonConvert.DeserializeObject<List<Ingridients>>(text);
        }

        public List<Ingridients> getSauce()
        {

            string text = System.IO.File.ReadAllText(@"./wwwroot/sauces.json");
            return JsonConvert.DeserializeObject<List<Ingridients>>(text);
        }

        public List<Ingridients> getCrust()
        {

            string text = System.IO.File.ReadAllText(@"./wwwroot/crusts.json");
            return JsonConvert.DeserializeObject<List<Ingridients>>(text);
        }

        public int placeOrder(PizzaOrderDetails[] orderDetails)
        {
            var details = JsonConvert.SerializeObject(orderDetails);
            var order = new Random().Next();
            System.IO.File.WriteAllText(@"C:\Pizza\" + $"{order}" + ".txt", details);
            return order;
        }
    }
}
